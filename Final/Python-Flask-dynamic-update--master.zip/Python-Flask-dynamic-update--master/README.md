# Python-Flask-dynamic-update-
here i have put all the files related to the dynamic update of web page with the help of flask and jasonify.
there is a basic code for simply updating the value of a dynamic variable result and then there are codes of connecting this to mqtt clould and google maps
to get the location through the mqtt cloud server and puting them on google maps
